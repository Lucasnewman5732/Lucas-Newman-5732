{
     import org.apache.spark.sql.SparkSession
//BASIC STATS//
 //create a data frame from the imported CSV
import org.apache.spark.sql.SparkSession
val df = spark.read
        .option("inferSchema", "true")
        .option("header", "true")
        .csv("/user/full_fifa18_data.csv")
         //MAKE REDUCED DF
val ovrDf= df.select(df("Value (M)").as("label"),$"age",$"height_cm",$"weight_kg", $"crossing",$"finishing",$"heading_accuracy",$"short_passing",$"volleys", $"dribbling",$"curve", $"free_kick_accuracy", $"long_passing", $"ball_control", $"acceleration", $"sprint_speed", $"agility", $"reactions", $"balance", $"shot_power", $"jumping", $"stamina", $"strength", $"long_shots", $"aggression", $"interceptions", $"positioning", $"vision", $"penalties", $"composure", $"marking", $"standing_tackle", $"sliding_tackle", $"gk_diving", $"gk_handling",$"gk_kicking", $"gk_positioning", $"gk_reflexes", $"weak_foot", $"att_rate_High", $"att_rate_Low", $"defend_rate_High", $"defend_rate_Low")
//ARRAYS WITH COL NAMES FOR EASY ACCESS
// for easy usage lets create an array with all column names of interest
val explanatoryCols = (Array("age","height_cm","weight_kg", "crossing","finishing","heading_accuracy","short_passing","volleys", "dribbling","curve", "free_kick_accuracy", "long_passing", "ball_control", "acceleration", "sprint_speed", "agility", "reactions", "balance", "shot_power", "jumping", "stamina", "strength", "long_shots", "aggression", "interceptions", "positioning", "vision", "penalties", "composure", "marking", "standing_tackle", "sliding_tackle", "gk_diving", "gk_handling","gk_kicking", "gk_positioning", "gk_reflexes", "weak_foot", "att_rate_High", "att_rate_Low", "defend_rate_High", "defend_rate_Low"))
val explanatoryCols2 = (Array("Overall", "Value (M)", "age","height_cm","weight_kg", "crossing","finishing","heading_accuracy","short_passing","volleys", "dribbling","curve", "free_kick_accuracy", "long_passing", "ball_control", "acceleration", "sprint_speed", "agility", "reactions", "balance", "shot_power", "jumping", "stamina", "strength", "long_shots", "aggression", "interceptions", "positioning", "vision", "penalties", "composure", "marking", "standing_tackle", "sliding_tackle", "gk_diving", "gk_handling","gk_kicking", "gk_positioning", "gk_reflexes", "weak_foot", "att_rate_High", "att_rate_Low", "defend_rate_High", "defend_rate_Low"))
val overallCols=(Array("Overall"))

    //VECTOR ASSEMBLER
//use a vector assembler to convert the columns of the features into a vector using the column name array we made above
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.linalg.Vectors
val assembler = new VectorAssembler().setInputCols(explanatoryCols).setOutputCol("features")
val featureVector = assembler.transform(df).select($"features")
val regressDf = assembler.transform(df).select($"Value (M)", $"features")

//STANDARDIZER
//We need to use the standard scaler on our data before we do PCA
import org.apache.spark.ml.feature.StandardScaler
val scaler = new StandardScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")
  .setWithStd(true)
  .setWithMean(false)
// Compute summary statistics by fitting the StandardScaler.
val scalerModel = scaler.fit(featureVector)
// Normalize each feature to have unit standard deviation.
val scaledData = scalerModel.transform(featureVector)
scaledData.show(3)
//We need to use the standard scaler on our data before we do PCA
import org.apache.spark.ml.feature.StandardScaler

val scaler2 = new StandardScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")
  .setWithStd(true)
  .setWithMean(false)

// Compute summary statistics by fitting the StandardScaler.
val scalerModel2 = scaler2.fit(regressDf)

// Normalize each feature to have unit standard deviation.
val scaledData2 = scalerModel2.transform(regressDf)
scaledData2.show(3)

//PCA ON SCALED MODEL
//conduct PCA for dimensionality reduction on scaled data note we omit the target variable from PCA
import org.apache.spark.ml.feature.PCA
import org.apache.spark.ml.linalg.Vectors

val pca = new PCA()
  .setInputCol("scaledFeatures")
  .setOutputCol("pcaFeatures")
  .setK(10)
  .fit(scaledData)
val pcaDf = pca.transform(scaledData)
//show the PCA features
val results = pcaDf.select("pcaFeatures")
results.show(3)
results.head(1)
//This returns the eigen values
val pca2 = new PCA()
  .setInputCol("scaledFeatures")
  .setOutputCol("pcaFeatures2")
  .setK(10)
  .fit(scaledData2)
val pcaDf2 = pca2.transform(scaledData2)
//show the PCA features
val results2 = pcaDf2.select("pcaFeatures2")
results2.show()
results2.head(1)

}