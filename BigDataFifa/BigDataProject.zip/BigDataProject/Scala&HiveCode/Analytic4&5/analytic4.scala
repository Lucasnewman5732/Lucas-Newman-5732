//Analytic 2.1: Difference in means 
// Split half-half data sets for T-test (there are 17739 observations) 
euro_df.createOrReplaceTempView("euro_df")
val df1 = spark.sql("select * from euro_df order by eur_wage desc limit 8869")
val df2 = spark.sql("select * from euro_df order by eur_wage limit 8869")

// High-paid players( by euro wage) 
df1.orderBy($"eur_wage".desc).show(3)

df1.orderBy($"eur_wage".desc).agg(avg(df1("eur_wage")).as("average")).show()

val avg1= df1.select(avg($"eur_wage").alias("wage1"), avg($"penalties").alias("p1"), avg($"stamina").alias("s1"),
avg($"height_cm").alias("h1"),avg($"weight_kg").alias("w1"),avg($"Overall").alias("o1"),avg($"age").alias("a1"))

// Low_paid players( by euro wage) 
df2.orderBy($"eur_wage".desc).show(3)

val avg2= df2.select(avg($"eur_wage").alias("wage2"), avg($"penalties").alias("p2"), avg($"stamina").alias("s2"),
avg($"height_cm").alias("h2"),avg($"weight_kg").alias("w2"),avg($"Overall").alias("o2"), avg($"age").alias("a2"))

//Difference
val avg_1=avg1.withColumn("id",monotonicallyIncreasingId+1)
val avg_2=avg2.withColumn("id",monotonicallyIncreasingId+1)

avg_1.createOrReplaceTempView("avg_1")
avg_2.createOrReplaceTempView("avg_2")

val diff =spark.sql("select wage1- wage2, p1-p2,s1-s2,h1-h2,w1-w2,o1-o2,a1-a2 from avg_1 v1 inner join avg_2 v2 on v1.id = v2.id")
diff.show()

val high= df1.select(avg($"eur_wage"), avg($"penalties"), avg($"stamina"),avg($"height_cm"),avg($"weight_kg"),avg($"Overall"),avg($"age"))
val low= df2.select(avg($"eur_wage"), avg($"penalties"), avg($"stamina"),avg($"height_cm"),avg($"weight_kg"),avg($"Overall"),avg($"age"))
high.show()
low.show()
diff.show()

