README
1. The "top_prospects.hql" file creates a hive table from the top_prospects csv file
2. the "best_investments.hql" file creates a view from that table where age and eur_value are minimized to identify the best cheap players, while scale_score is maximized and potential is greater than or equal to 85. This view has the top 500 results and identifies the best deals for players that a club should pursue.
