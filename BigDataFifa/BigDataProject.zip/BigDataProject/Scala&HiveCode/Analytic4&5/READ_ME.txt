- Please load full_fifa18_data.csv file to VM, and then hdfs before running my scala code.

hdfs dfs –put full_fifa18_data.csv /user/

- My code will run two analytics- 2.1 and 2.2: 
  Analytics 2.1 calculate the difference between average of each two player group: high-paid & low-paid
  Analytics 2.2 run regression of the six variables against eur_wage to find how much they explain players' wages.

