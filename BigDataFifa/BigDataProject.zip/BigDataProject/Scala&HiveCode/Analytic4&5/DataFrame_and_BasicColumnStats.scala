// Loading data into Spark Dataframe 
val sqlContext = new org.apache.spark.sql.SQLContext(sc)
val full_data =sqlContext.read.format("csv").option("header","true").option("inferSchema","true").load("/user/full_fifa18_data.csv")
val euro_df= full_data.select("id","Name","Position","Overall","club","age","league","height_cm","weight_kg","nationality","eur_value","eur_wage","stamina","penalties")
val euro_set1=euro_df.select("id","Name","Overall","age","height_cm","weight_kg","eur_wage","penalties")

//Basic stats (including min, max, average)
euro_set1.describe("eur_wage","age","height_cm","weight_kg","penalties").show()

// Number of null values
euro_set1.select(euro_set1.columns.map(c => sum(col(c).isNull.cast("int")).alias(c)): _*).show

// Number of distinct values 
euro_df.select(euro_df.columns.map(c => countDistinct(col(c)).alias(c)): _*).show

// Top 10 Values And Their Percentage *

val wage=euro_set1.groupBy("eur_wage").count().toDF
val age=euro_set1.groupBy("age").count().toDF
val height=euro_set1.groupBy("height_cm").count().toDF
val weight=euro_set1.groupBy("weight_kg").count().toDF
val penal=euro_set1.groupBy("penalties").count().toDF

// Wage in Euro 
wage.select($"eur_wage",$"count").orderBy($"eur_wage".desc).withColumn("percent", $"count"/euro_set1.count()).limit(10).show()

// Age 
age.select($"age",$"count").orderBy($"age".desc).withColumn("percent", $"count"/euro_set1.count()).limit(10).show()

// Height (cm) 
height.select($"height_cm",$"count").orderBy($"height_cm".desc).withColumn("percent", $"count"/euro_set1.count()).limit(10).show()

// Weight (kg) 
weight.select($"weight_kg",$"count").orderBy($"weight_kg".desc).withColumn("percent", $"count"/euro_set1.count()).limit(10).show()

// Penalties 
penal.select($"penalties",$"count").orderBy($"penalties".desc).withColumn("percent", $"count"/euro_set1.count()).limit(10).show()
