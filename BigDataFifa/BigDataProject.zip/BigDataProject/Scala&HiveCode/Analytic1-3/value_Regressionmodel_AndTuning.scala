{
    ///*****PLEASE READ THESE COMMENTS*****////
    //**NOTE PLEASE RUN PRINT STATEMENTS IN THE SPARK SHELL//
    //ELASTIC NET REGRESSION WAS DONE WHERE TARGET IS VALUE
    //RIDGE REGRESSION ON PCA MODEL WAS DONE WITH TARGET AS VALUE
    //GLM REGRESSION WAS DONE ON VALUE
    //MODEL TUNING WAS DONE WITH PARAM GRID//
     import org.apache.spark.sql.SparkSession
//BASIC STATS//
 //create a data frame from the imported CSV
import org.apache.spark.sql.SparkSession
val df = spark.read
        .option("inferSchema", "true")
        .option("header", "true")
        .csv("/user/full_fifa18_data.csv")
         //MAKE REDUCED DF
val ovrDf= df.select(df("Value (M)").as("label"),$"age",$"height_cm",$"weight_kg", $"crossing",$"finishing",$"heading_accuracy",$"short_passing",$"volleys", $"dribbling",$"curve", $"free_kick_accuracy", $"long_passing", $"ball_control", $"acceleration", $"sprint_speed", $"agility", $"reactions", $"balance", $"shot_power", $"jumping", $"stamina", $"strength", $"long_shots", $"aggression", $"interceptions", $"positioning", $"vision", $"penalties", $"composure", $"marking", $"standing_tackle", $"sliding_tackle", $"gk_diving", $"gk_handling",$"gk_kicking", $"gk_positioning", $"gk_reflexes", $"weak_foot", $"att_rate_High", $"att_rate_Low", $"defend_rate_High", $"defend_rate_Low")
//ARRAYS WITH COL NAMES FOR EASY ACCESS
// for easy usage lets create an array with all column names of interest
val explanatoryCols = (Array("age","height_cm","weight_kg", "crossing","finishing","heading_accuracy","short_passing","volleys", "dribbling","curve", "free_kick_accuracy", "long_passing", "ball_control", "acceleration", "sprint_speed", "agility", "reactions", "balance", "shot_power", "jumping", "stamina", "strength", "long_shots", "aggression", "interceptions", "positioning", "vision", "penalties", "composure", "marking", "standing_tackle", "sliding_tackle", "gk_diving", "gk_handling","gk_kicking", "gk_positioning", "gk_reflexes", "weak_foot", "att_rate_High", "att_rate_Low", "defend_rate_High", "defend_rate_Low"))
val explanatoryCols2 = (Array("Overall", "Value (M)", "age","height_cm","weight_kg", "crossing","finishing","heading_accuracy","short_passing","volleys", "dribbling","curve", "free_kick_accuracy", "long_passing", "ball_control", "acceleration", "sprint_speed", "agility", "reactions", "balance", "shot_power", "jumping", "stamina", "strength", "long_shots", "aggression", "interceptions", "positioning", "vision", "penalties", "composure", "marking", "standing_tackle", "sliding_tackle", "gk_diving", "gk_handling","gk_kicking", "gk_positioning", "gk_reflexes", "weak_foot", "att_rate_High", "att_rate_Low", "defend_rate_High", "defend_rate_Low"))
val overallCols=(Array("Overall"))

    //VECTOR ASSEMBLER
//use a vector assembler to convert the columns of the features into a vector using the column name array we made above
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.linalg.Vectors
val assembler = new VectorAssembler().setInputCols(explanatoryCols).setOutputCol("features")
val featureVector = assembler.transform(df).select($"features")
val regressDf = assembler.transform(df).select($"Value (M)", $"features")

//STANDARDIZER
//We need to use the standard scaler on our data before we do PCA
import org.apache.spark.ml.feature.StandardScaler
val scaler = new StandardScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")
  .setWithStd(true)
  .setWithMean(false)
// Compute summary statistics by fitting the StandardScaler.
val scalerModel = scaler.fit(featureVector)
// Normalize each feature to have unit standard deviation.
val scaledData = scalerModel.transform(featureVector)

//We need to use the standard scaler on our data before we do PCA
import org.apache.spark.ml.feature.StandardScaler

val scaler2 = new StandardScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")
  .setWithStd(true)
  .setWithMean(false)

// Compute summary statistics by fitting the StandardScaler.
val scalerModel2 = scaler2.fit(regressDf)

// Normalize each feature to have unit standard deviation.
val scaledData2 = scalerModel2.transform(regressDf)


//PCA ON SCALED MODEL
//conduct PCA for dimensionality reduction on scaled data note we omit the target variable from PCA
import org.apache.spark.ml.feature.PCA
import org.apache.spark.ml.linalg.Vectors

val pca = new PCA()
  .setInputCol("scaledFeatures")
  .setOutputCol("pcaFeatures")
  .setK(10)
  .fit(scaledData)
val pcaDf = pca.transform(scaledData)
//show the PCA features
val results = pcaDf.select("pcaFeatures")

//This returns the eigen values
val pca2 = new PCA()
  .setInputCol("scaledFeatures")
  .setOutputCol("pcaFeatures2")
  .setK(10)
  .fit(scaledData2)
val pcaDf2 = pca2.transform(scaledData2)
//show the PCA features
val results2 = pcaDf2.select("pcaFeatures2")

///Fitting Scaled Features to Regression Model
val ovrDf2= pcaDf2.select(pcaDf2("Value (M)").as("label"),pcaDf2("scaledFeatures").as("features"))
val Array(training, test) = ovrDf2.randomSplit(Array(0.9, 0.1), seed = 12345)

import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}



///Elastic Net Regression on Value
val lr = new LinearRegression()
  .setMaxIter(10)
  .setRegParam(0.3)
  .setElasticNetParam(0.8)



val lrModel = lr.fit(ovrDf2)
// Print the coefficients and intercept for linear regression
println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")
// Summarize the model over the training set and print out some metrics
val summary = lrModel.summary
println(s"numIterations: ${summary.totalIterations}")

//println(s"objectiveHistory: ${summary.objectiveHistory.toList}")
//println(s"RMSE: ${summary.rootMeanSquaredError}")
//println(s"r2: ${summary.r2}")
//println(s"Coefficient Standard Errors: ${summary.coefficientStandardErrors.mkString(",")}")
//println(s"T Values: ${summary.tValues.mkString(",")}")
//println(s"P Values: ${summary.pValues.mkString(",")}")



//RidgeRegression for Value using PCA features


//Fitting Scaled Features to Regression Model
val pcadata= pcaDf2.select(pcaDf2("Value (M)").as("label"),pcaDf2("pcaFeatures2").as("features"))
val Array(training2, test2) = ovrDf2.randomSplit(Array(0.9, 0.1), seed = 12345)

import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}




val pcalr = new LinearRegression()
  .setMaxIter(10)
  .setRegParam(0.3)
  .setElasticNetParam(0.0)



val pcalrModel = pcalr.fit(pcadata)
// Print the coefficients and intercept for linear regression
println(s"Coefficients: ${pcalrModel.coefficients} Intercept: ${pcalrModel.intercept}")
// Summarize the model over the training set and print out some metrics
val pcasummary = pcalrModel.summary
println(s"numIterations: ${summary.totalIterations}")

//println(s"objectiveHistory: ${pcasummary.objectiveHistory.toList}")
//println(s"RMSE: ${pcasummary.rootMeanSquaredError}")
//println(s"r2: ${pcasummary.r2}")
//println(s"Coefficient Standard Errors: ${pcasummary.coefficientStandardErrors.mkString(",")}")
//println(s"T Values: ${pcasummary.tValues.mkString(",")}")
//println(s"P Values: ${pcasummary.pValues.mkString(",")}")


//GLM on value
///Fitting Scaled Features to Regression Model

import org.apache.spark.ml.regression.GeneralizedLinearRegression

val glmdf= pcaDf2.select(pcaDf2("Value (M)").as("label"),pcaDf2("scaledFeatures").as("features"))

val glr = new GeneralizedLinearRegression()
  .setFamily("gaussian")
  .setLink("Identity")
  .setMaxIter(10)
  .setRegParam(0.5)

// Fit the model
val glrmodel = glr.fit(glmdf)

// Print the coefficients and intercept for generalized linear regression model
println(s"Coefficients: ${glrmodel.coefficients}")
println(s"Intercept: ${glrmodel.intercept}")

// Summarize the model over the training set and print out some metrics
val glrsummary = glrmodel.summary
//println(s"Coefficient Standard Errors: ${glrsummary.coefficientStandardErrors.mkString(",")}")
//println(s"T Values: ${glrsummary.tValues.mkString(",")}")
//println(s"P Values: ${glrsummary.pValues.mkString(",")}")
//println(s"Dispersion: ${glrsummary.dispersion}")
//println(s"Null Deviance: ${glrsummary.nullDeviance}")
//println(s"Residual Degree Of Freedom Null: ${glrsummary.residualDegreeOfFreedomNull}")
//println(s"Deviance: ${glrsummary.deviance}")
//println(s"Residual Degree Of Freedom: ${glrsummary.residualDegreeOfFreedom}")
//println(s"AIC: ${glrsummary.aic}")
//println("Deviance Residuals: ")


//Regression Model Tuning
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}
val Array(training3, test3) = ovrDf2.randomSplit(Array(0.9, 0.1), seed = 12345)

import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}



val lrtune = new LinearRegression()
  .setMaxIter(10)

// We use a ParamGridBuilder to construct a grid of parameters to search over.
// TrainValidationSplit will try all combinations of values and determine best model using
// the evaluator.
val paramGrid = new ParamGridBuilder()
  .addGrid(lrtune.regParam, Array(0.1, 0.01))
  .addGrid(lrtune.fitIntercept)
  .addGrid(lrtune.elasticNetParam, Array(0.0, 0.5, 1.0))
  .build()

// In this case the estimator is simply the linear regression.
// A TrainValidationSplit requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
val trainValidationSplit = new TrainValidationSplit()
  .setEstimator(lrtune)
  .setEvaluator(new RegressionEvaluator)
  .setEstimatorParamMaps(paramGrid)
  // 80% of the data will be used for training and the remaining 20% for validation.
  .setTrainRatio(0.8)

// Run train validation split, and choose the best set of parameters.
val modeltune = trainValidationSplit.fit(training3)
// Make predictions on test data. model is the model with combination of parameters
// that performed best.
modeltune.transform(test3)
  .select("features", "label", "prediction")
  .show()

}