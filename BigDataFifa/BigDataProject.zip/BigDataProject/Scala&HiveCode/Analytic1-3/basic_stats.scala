{
      import org.apache.spark.sql.SparkSession
//BASIC STATS//
 //create a data frame from the imported CSV
import org.apache.spark.sql.SparkSession
val df = spark.read
        .option("inferSchema", "true")
        .option("header", "true")
        .csv("/user/full_fifa18_data.csv")
         df.printSchema()
         df.show(3)
//Summary statistics about descriptive attributes
df.describe("Overall", "Value (M)", "Potential", "age", "height_cm", "weight_kg", "foot_right").show()


//basic player card attributes note international rep is on a scale of 1-5 where the greater the number the better
df.describe("pac", "sho", "pas", "dri", "defend", "phy", "international_reputation").show()

//Show attacking stats
df.describe("crossing","finishing","heading_accuracy","short_passing","volleys").show()
//skill stats note weak foot is on scale of 1-5
df.describe("dribbling","curve", "free_kick_accuracy", "long_passing", "ball_control", "weak_foot").show()
//movement stats
df.describe("acceleration", "sprint_speed", "agility", "reactions", "balance").show()
//power stats
df.describe("shot_power", "jumping", "stamina", "strength", "long_shots").show()
//mentality stats
df.describe("aggression", "interceptions", "positioning", "vision", "penalties", "composure").show()
//defensive stats
df.describe("marking", "standing_tackle", "sliding_tackle","interceptions").show()
// goal keeping stats
df.describe("gk_diving", "gk_handling","gk_kicking", "gk_positioning", "gk_reflexes").show()

//traits
df.describe("att_rate_High", "att_rate_Low", "att_rate_Medium", "defend_rate_High", "defend_rate_Low", "defend_rate_Medium").show()

}