// Analytic 2.2: Regression
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.regression.LinearRegression

val df = euro_df.select(euro_df("eur_wage").as("label"),$"Overall",$"age",$"stamina",$"penalties",$"height_cm",$"weight_kg")
val assembler = new VectorAssembler().setInputCols(Array("Overall","age","stamina","penalties","height_cm","weight_kg")).setOutputCol("features")
val transform=assembler.transform(df).select($"label",$"features")


val lr = new LinearRegression()
val lrModel =lr.fit(transform)
val trainingSummary = lrModel.summary

println(s"r2: ${trainingSummary.r2}")
println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")
trainingSummary.pValues

