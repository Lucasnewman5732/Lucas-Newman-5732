//1. Create table using hive
players.hive
//2. create a dataframe for  the following columns using  SPARKSQL
//open spark shell
//The steps below were followed using spark sql
//create dataframe  for the columns to be used
val dFplayers = spark.sql("select full_name,nationality, club,league, Overall, age, eur_wage from players")

//display the schema
dFplayers.printSchema()

//print sample records for over view
dFplayers.take(5).foreach(println)

// basic statistics for numerical columns
dFplayers.describe("full_name","nationality","league","club","Overall","age","eur_wage").show()

//compute the number of records that have specific fields missing as a %, as follows:
{
dFplayers.select($"full_name").groupBy($"full_name").count().select($"full_name", (($"count" / dFplayers.count())*100).$
dFplayers.select($"nationality").groupBy($"nationality").count().select($"nationality", (($"count" / dFplayers.count())$
dFplayers.select($"club").groupBy($"club").count().select($"club", (($"count" / dFplayers.count())*100).alias("percent_$
dFplayers.select($"league").groupBy($"league").count().select($"league", (($"count" / dFplayers.count())*100).alias("pe$
dFplayers.select($"Overall").groupBy($"Overall").count().select($"Overall", (($"count" / dFplayers.count())*100).alias($
dFplayers.select($"age").groupBy($"age").count().select($"age", (($"count" / dFplayers.count())*100).alias("percent_rec$
dFplayers.select($"eur_wage").groupBy($"eur_wage").count().select($"eur_wage", (($"count" / dFplayers.count())*100).ali$
}
//Analytics
//who are the top  10 young players and what country are they  from 
:What is the  distribution of  players based on nationality​ league and Club ​  
val sqlDF = spark.sql("select nationality, club, Overall, age, eur_wage from players where Overall > 66 ").show(30)
//natuionality 
//players with eur_wage less than averge
//salary distribution  greater than average 
val sqlDF = spark.sql("select nationality, club, Overall, age, eur_wage from players where eur_wage >  11634.70 ").show(20)
//salary distribution less than average 
val sqlDF = spark.sql("select nationality, club, Overall, age, eur_wage from players where eur_wage <  11634.70 ").show(20)