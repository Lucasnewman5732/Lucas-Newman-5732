TABLE OF CONTENTS

1. DATAFRAME CREATION AND BASIC STATS: "basic_stats.scala"

2. DATA STANDARDIZED AND PCA: "standardize_pca.scala"

3. VALUE REGRESSION MODELING & HYPERPARAMETER TUNING: 
"value_RegressionModel_AndTuning.scala"

4. RECOMMENDER SYSTEM ON SCORE: "recsys1.scala"

5. RECOMMENDER SYSTEM ON BUYING CAPACITY: "recsys2.scala"



	NOTES
Upload all scala files and data files to the sandboz=x
**//Main HDFS commands
Now add all the data added to HDFS on the sandbox for example:
**//hdfs dfs -put full_fifa18_data.csv /user
**//hdfs dfs -put Full_DF.csv /user
etc for all the files

